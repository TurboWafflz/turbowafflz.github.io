echo 'EasySSH Installer v1.5'
echo 'Press the number of your choice:'
echo '[1] Install EasySSH'
echo '[2] Uninstall EasySSH'
echo '[q] Quit The installer'
read -n 1 choice
if [ $choice = 'q' ]
then
exit
fi
if [ $choice = '1' ]
then
clear
echo 'Installing...'
if [ -e $HOME/easysshbookmarks.txt ]
then
echo 'Keeping your current bookmarks...'
else
echo 'Copying bookmarks file...'
cp ./easysshbookmarks.txt $HOME/easysshbookmarks.txt
fi
echo 'Copying EasySSH program...'
sudo cp ./easyssh.sh /usr/bin/easyssh
echo 'Making EasySSH executable...'
sudo chmod +x /usr/bin/easyssh
echo 'Done!'
echo 'EasySSH is now installed! Type easyssh to run it.'
exit
fi
if [ $choice = '2' ]
then
clear
echo 'Uninstalling EasySSH'
sudo rm /usr/bin/easyssh
clear
echo 'EasySSH Uninstalled'
fi
