tput setaf 1
echo "Installing dependencies..."
tput sgr0
apt install choosewm lxpanel feh openbox zenity libnotify-bin compton
tput setaf 1
echo "Setting up assets"
tput sgr0
mkdir /usr/share/iiui/
chmod +x ./bin/*
cp -r -a -p ./share/* /usr/share/iiui/
cp -r -a -p ./bin/* /usr/local/bin/
tput setaf 1
echo "Setting up IIUI..."
#tput sgr0
##cp ./iiui /usr/local/bin/
cp -r -a -p ./iiui.desktop /usr/share/xsessions/
tput setaf 2
echo "Done! You can now login and use IIUI as your desktop environment."
tput sgr0
