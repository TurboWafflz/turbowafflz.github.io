#!/bin/bash
clear
tput setaf 3
figlet -f future "[SET]"
tput sgr0
echo 'Time (In seconds):'
read x
while [ "$x" != "0" ]
do
clear
tput setaf 2
figlet -f future "[RUNNING]"
figlet -f bigmono12 $x
x=`expr $x - 1`
sleep 1
done
while /bin/true
do
clear
tput setaf 1
figlet -f bigmono12 'DONE'
sleep 0.1
aplay ./beep_lo.wav
clear
tput setaf 2
figlet -f bigmono12 'DONE!'
sleep 0.1
clear
tput setaf 3
figlet -f bigmono12 'DONE!!'
sleep 0.1
aplay ./beep_hi.wav
clear
done
