apt install tdc
apt install choosewm
apt install docky
apt install feh
if [ -f $HOME/iiui.png ]
then
/bin/true/
else
cp ./iiui.png $HOME
fi
cp ./iiui /usr/local/
cp ./iiui.desktop /usr/share/xsesions
echo "Done!"
