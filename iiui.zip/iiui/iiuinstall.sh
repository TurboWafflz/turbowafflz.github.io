apt install tdc
apt install choosewm
apt install docky
apt install feh
apt install openbox
if [ -f $HOME/iiui.png ]
then
/bin/true
else
cp ./iiui.png $HOME
fi
cp ./iiui /usr/local/bin/
chmod +x /usr/local/bin/iiui
cp ./iiui.desktop /usr/share/xsessions/
echo "Done!"
