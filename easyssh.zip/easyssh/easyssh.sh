bselect=''
choice=''
if [ `/bin/sed -r -e 's/\x0.*//' /proc/$$/cmdline` != "bash" ]
then
    echo 'Your terminal may not be compatible. EasySSH is designed to run under Bash which you are not currently using. Press Ctrl-c to exit, or press enter to run EasySSH anyway.'
    read e
fi
clear
tput setaf 2
echo 'ImaginaryInfinity EasySSH'
echo 'v1.0'
echo ''
echo 'Press Number of choice:'
echo '|#|    |Choice|'
echo '[1] Connect to bookmark'
echo '[2] Input IP'
echo '[q] Quit'
read -n 1 choice
clear
if [ $choice = 1 ]
then
    echo 'EasyBookmarks:'
    echo 'Enter number Of choice and press [ENTER]'
    echo '#   Name'
    cat $HOME/easysshbookmarks.txt | awk -F, '{print $1,$2}'
    echo -n 'Choice:'
    read bselect
    x=`sed -n "$bselect"p $HOME/easysshbookmarks.txt | awk -F, '{print $3}'`
    z=`sed -n "$bselect"p $HOME/easysshbookmarks.txt | awk -F, '{print $4}'`
    y=`sed -n "$bselect"p $HOME/easysshbookmarks.txt | awk -F, '{print $5}'`
fi
if [ $choice = 2 ]
then
echo -n 'IP Address:'
read x
echo -n 'User:'
read z
echo 'Enable X support? [y/n]'
read y
if [ $y = 'y' ]
then
    y=-Y
else
    y=''
fi
fi
if [ $choice = 'q' ]
then
    echo 'Goodbye!'
    exit
fi
clear
echo "Connecting to $x as $z..."
tput sgr0
ssh $y $x -l $z
tput setaf 2
echo 'Disconnected from' $x
