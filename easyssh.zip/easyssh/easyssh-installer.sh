echo 'EasySSH Installer v1.0'
echo 'Press the number of your choice:'
echo '[1] Install EasySSH'
echo '[2] Uninstall EasySSH'
echo '[q] Quit The installer'
read -n 1 choice
if [ $choice = 'q' ]
then
exit
fi
if [ $choice = '1' ]
then
clear
echo 'Installing...'
cp ./easysshbookmarks.txt $home/easysshbookmarks.txt
sudo cp ./easyssh.sh /usr/bin/easyssh
sudo chmod +x /usr/bin/easyssh
clear
echo 'EasySSH is now installed! Type easyssh to run it.'
exit
fi
if [ $choice = '2' ]
then
clear
echo 'Uninstalling EasySSH'
sudo rm /usr/bin/easyssh
clear
echo 'EasySSH Uninstalled'
fi
