sudo ./.install.sh
