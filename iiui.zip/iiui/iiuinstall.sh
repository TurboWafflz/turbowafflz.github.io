tput setaf 1
echo "Installing dependencies..."
tput sgr0
apt install choosewm fbpanel feh openbox zenity libnotify-bin
tput setaf 1
echo "Setting up assets"
tput sgr0
mkdir /usr/share/iiui/
cp ./iiui.png /usr/share/iiui/
cp ./iiui-begin.png /usr/share/iiui/
tput setaf 1
echo "Installing IIUI..."
tput sgr0
cp ./iiui /usr/local/bin/
chmod +x /usr/local/bin/iiui
cp ./iiui.desktop /usr/share/xsessions/
tput setaf 2
echo "Done! You can now login and use IIUI as your desktop environment."
tput sgr0
