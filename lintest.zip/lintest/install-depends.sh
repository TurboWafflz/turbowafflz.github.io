sudo apt install boxes lolcat figlet toilet cowsay ncurses-bin speedtest-cli
