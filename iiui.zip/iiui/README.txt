
To install IIUI:
Simply type sudo sh ./iiuinstall.sh in the iiui folder


To update IIUI:
Move the IIUI folder to your home directory, then run sudo updateiiui


Reconfiguring IIUI:
To re-run the first time setup wizard run iiui-config



NOTE: to install IIUI you need administrator privlages on this computer.
