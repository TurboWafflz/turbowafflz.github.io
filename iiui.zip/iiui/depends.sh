yes | apt install choosewm lxpanel feh openbox zenity libnotify-bin compton
